const hourE= document.getElementById("hour")
const minutesE = document.getElementById("minutes")
const secondsE = document.getElementById("seconds")
const ampmE = document.getElementById("ampm");

function updateclock(){
    let hour = new Date().getHours()
    let minutes = new Date().getMinutes()
    let seconds = new Date().getSeconds()
    let ampm = "AM"

    if(hour > 12){
        hour = hour - 12
        ampm = "PM"
    }

    if(hour < 10){
        hour = "0" + hour
    }
    if(minutes < 10){
        minutes = "0" + minutes
    }
    if(seconds< 10){
        seconds = "0" + seconds
    }

    hourE.innerText = hour;
    minutesE.innerText = minutes;
    secondsE.innerText = seconds;
    ampmE.innerText = ampm;
    setTimeout(()=>{
        updateclock()
    }, 1000)
}

updateclock()